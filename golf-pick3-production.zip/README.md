
# Golf Pick 3 App

## Install

npm install

## Run

npm run dev

## Deploy

Upload to GitHub then connect to Vercel.
