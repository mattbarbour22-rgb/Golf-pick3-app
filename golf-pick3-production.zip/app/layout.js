
import './globals.css';

export const metadata = {
  title: 'Golf Pick 3',
};

export default function RootLayout({ children }) {
  return (
    <html lang='en'>
      <body>{children}</body>
    </html>
  );
}
