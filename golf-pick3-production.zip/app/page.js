
export default function Home() {
  const players = [
    {
      name: "R Fowler",
      picks: ["Rory McIlroy", "Cameron Young", "Xander Schauffele"],
      eligible: true,
      rank: 1,
      movement: "up"
    },
    {
      name: "Jonesy",
      picks: ["Rory McIlroy", "Cameron Young", "Justin Thomas"],
      eligible: true,
      rank: 2,
      movement: "down"
    },
  ];

  return (
    <main className="min-h-screen bg-green-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">

        <div className="bg-white rounded-3xl shadow-lg p-6">
          <h1 className="text-4xl font-bold text-green-900">
            Golf Pick 3 Competition
          </h1>

          <p className="text-green-700 mt-2">
            Live leaderboard for the 4 men's golf majors
          </p>
        </div>

        <div className="bg-white rounded-3xl shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-6">
            Live Competition Leaderboard
          </h2>

          <table className="w-full">
            <thead>
              <tr className="border-b text-left">
                <th className="pb-3">Rank</th>
                <th className="pb-3">Move</th>
                <th className="pb-3">Player</th>
                <th className="pb-3">Eligible</th>
              </tr>
            </thead>

            <tbody>
              {players.map((player) => (
                <tr key={player.name} className="border-b">
                  <td className="py-4 font-bold">#{player.rank}</td>

                  <td className="py-4">
                    {player.movement === "up" ? "▲" : "▼"}
                  </td>

                  <td className="py-4 font-semibold">
                    {player.name}
                  </td>

                  <td className="py-4">
                    {player.eligible ? "LIVE" : "OUT"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </main>
  );
}
